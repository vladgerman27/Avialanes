(function( $, window, document, undefined ) {
    var pluginName = "twidget",
        defaults = {
            locale: "ru",
            marker: 1111,
            type: 'avia',
            hide_logos: false,
            open_in_new_tab: true,
            default_origin: '',
            default_destination: '',
			lock_destination: false,
            localization: {
                avia_tab_caption: 'Авиабилеты',
                avia_logo_caption: 'Поиск дешёвых авиабилетов',
                avia_input_origin_label: 'Город вылета',
                avia_input_destination_label: 'Город прибытия',
                avia_input_date_start: 'Туда',
                avia_input_date_end: 'Обратно',
                avia_passengers_select_caption: 'Пассажиры/Класс',
                avia_passengers_caption_1: 'пассажир',
                avia_passengers_caption_2: 'пассажира',
                avia_passengers_caption_5: 'пассажиров',
                avia_passengers_select_adults: 'Взрослые',
                avia_passengers_select_children: 'Дети до 12 лет',
                avia_passengers_select_infants: 'Дети до 2 лет',
                avia_passengers_economy_class: 'эконом',
                datepicker_language: 'ru',
                avia_passengers_business_class: 'бизнес-класс',
                avia_passengers_business_class_checkbox: 'Перелет бизнес-классом',
                avia_passengers_select_ready_button: 'Готово',
                avia_submit_button_text: 'Найти билеты',
                avia_all_airports_caption: 'Все аэропорты',
                datepicker_return_ticket_caption: 'Обратный билет не нужен',
                weekdays_short: ["вс", "пн", "вт", "ср", "чт", "пт", "сб"],
                month_names: ["Января","Февраля","Марта","Апреля","Мая","Июня","Июля","Августа","Сентября","Октября","Ноября","Декабря"],
                avia_logo_link: 'https://www.aviasales.kz/',
                avia_logo_content: '<div class="twidget-logo-image twidget-aviasales-logo-img" width="30" height="30"></div>aviasales',
                avia_submit_domain : 'https://hydra.aviasales.ru/searches/new'
            }
        },
        date = new Date(),
        dateOneWeekLater = new Date(),
        dateTwoWeekLater = new Date();

    dateOneWeekLater.setDate(date.getDate() + 7);
    dateTwoWeekLater.setDate(date.getDate() + 14);

    function Plugin ( element, options ) {
        this.element = element;
        this.settings = $.extend( {}, defaults, options );
        this._defaults = defaults;
        this._name = pluginName;
        this.init();
    }

    $.extend( Plugin.prototype, {
        init: function() {
            this.widget_html();

            var container = $( this.element),
                _this = this;

            container.find('input[name="marker"]').val(this.settings.marker);

            if(this.settings.hide_logos){
                container.find('.twidget-header').remove();
            }

            switch(this.settings.type) {
                case 'avia':{
                    container.find('.twidget-tab-links').remove();
                    container.find('#twidget-tab2').remove();
                }
            }

            if(this.settings.locale == 'ru') {
                container.find('input[name="with_request"]').remove();
                container.find('input[name="oneway"]').remove();
            }

            var origin_iata_input       = container.find('input[name="origin_iata"]'),
                destination_iata_input  = container.find('input[name="destination_iata"]'),
                oneway_input            = container.find('input[name="oneway"]'),
                trip_class_input        = container.find('input[name="trip_class"]'),
                pas_count_label         = container.find('#twidget-pas'),
                adults_pas_input        = container.find('#twidget-passenger-form input[name="adults"]'),
                children_pas_input      = container.find('#twidget-passenger-form input[name="children"]'),
                infants_pas_input       = container.find('input[name="infants"]');+

            container.find('.twidget-tab-links a').on('click', function(e)  {
                var currentAttrValue = $(this).attr('href'),
                    currentTabContentHeight = container.find('.twidget-tab-content').height()+20;

                container.find('.twidget-tab-content').css({height: currentTabContentHeight});
                container.find('.twidget-tabs ' + currentAttrValue).siblings().fadeOut(200);
                setTimeout(function(){container.find('.twidget-tabs ' + currentAttrValue).fadeIn(200);container.find('.twidget-tab-content').css({height: 'auto'});}, 250);


                $(this).parent('li').addClass('active').siblings().removeClass('active');

                e.preventDefault();
            });

            container.find('.twidget-passengers-detail').click(function(){
                $(this).toggleClass('active');
                container.find('#twidget-passenger-form').fadeToggle(65);
            });

            container.find('.twidget-passengers-ready-button').click(function(){
                container.find('.twidget-passengers-detail').trigger('click');
            });

            $(document).on("click", "#"+this.element.id+" .twidget-q-btn", function() {
                var button = $(this),
                    input = button.parent().find("input"),
                    newVal = parseFloat(input.val()),
                    adults_pas_count = parseFloat(adults_pas_input.val()),
                    children_pas_count = parseFloat(children_pas_input.val()),
                    infants_pas_count = parseFloat(infants_pas_input.val());

                if (button.text() == "+") {
                    if((button.attr('data-age') == 'adults' || button.attr('data-age') == 'children')  && (adults_pas_count + children_pas_count + infants_pas_count ) < 9) { 
                        newVal++;
                    }
                    if(button.attr('data-age') == 'infants'  && newVal < adults_pas_count && (adults_pas_count + children_pas_count + infants_pas_count ) < 9) { 
                        newVal++;
                    }
                    if(button.attr('data-age') == 'adults-g' && newVal < 4) { 
                        newVal++;
                    }
                    if(button.attr('data-age') == 'children-g' && newVal < 3) { 
                        newVal++;
                        container.find('#twidget-guest-form .twidget-pas-class ul').append( 
                            '<li>' +
                            '<div class="twidget-cell twidget-age-name">' + _this.settings.localization.hotel_guests_select_children_age + '</div>' +
                            '<div class="twidget-cell twidget-age-select">' +
                            '<span class="twidget-dec twidget-q-btn" data-age="one-child">-</span><span class="twidget-num"><input type="text" name="children['+newVal+']" value="8"></span><span class="twidget-inc twidget-q-btn" data-age="one-child">+</span>' +
                            '</div>' +
                            '</li>'
                        );
                        container.find('#twidget-guest-form .twidget-pas-class').show();
                    }
                    if(button.attr('data-age') == 'one-child' && newVal < 17) {
                        newVal++;
                    }
                } else {
                    if (input.val() > 0) {
                        if((button.attr('data-age') == 'adults' || button.attr('data-age') == 'adults-g') && input.val() == 1) {
                            return false;
                        }
                        newVal--;
                        if(button.attr('data-age') == 'adults' && infants_pas_count > newVal ) { 
                            infants_pas_input.val(newVal);
                        }
                        if(button.attr('data-age') == 'children-g') { 
                            container.find('#twidget-guest-form .twidget-pas-class li:last-child').remove();
                            if(newVal == 0) {
                                container.find('#twidget-guest-form .twidget-pas-class').hide();
                            }
                        }
                    } else {
                        newVal = 0;
                    }
                }
                input.val(newVal);
                pas_count_label.html(0);
                container.find('#twidget-passenger-form input[name="adults"], #twidget-passenger-form input[name="children"], input[name="infants"]').trigger('change');
            });

            container.find('#twidget-passenger-form input[name="adults"], #twidget-passenger-form input[name="children"], input[name="infants"]').on('change', function() {
                var current_count = parseFloat(pas_count_label.html()),
                    input_count = parseFloat($(this).val());
                pas_count_label.html(current_count+input_count);
                if(current_count+input_count >= 5) {
                    container.find('.twidget-pas-caption').text(_this.settings.localization.avia_passengers_caption_5);
                } else if(current_count+input_count != 1){
                    container.find('.twidget-pas-caption').text(_this.settings.localization.avia_passengers_caption_2);
                } else {
                    container.find('.twidget-pas-caption').text(_this.settings.localization.avia_passengers_caption_1);
                }
            });

            container.find('.twidget-pass-class+label').click(function(){
                container.find(".twidget-pass-class").trigger('click');
            });
            container.find(".twidget-pass-class").change(function() {
                if(this.checked) {
                    container.find('.twidget-form-list li .twidget-passengers-detail .twidget-class').html(_this.settings.localization.avia_passengers_business_class);
                    trip_class_input.val(1);
                }
                else{
                    container.find('.twidget-form-list li .twidget-passengers-detail .twidget-class').html(_this.settings.localization.avia_passengers_economy_class);
                    trip_class_input.val(0);
                }
            });

            var dateSelect     = container.find('#twidget-flight-datepicker'),
                dateDepart     = container.find('input[name="depart_date"]'),
                dateReturn     = container.find('input[name="return_date"]'),
                iconReturnCal  = container.find('.twidget-return-date .twidget-icon-cal'),
                iconReturnDel  = container.find('.twidget-return-date .twidget-icon-delete'),
                spanDepart     = container.find('.twidget-date-depart'),
                spanReturn     = container.find('.twidget-date-return'),
                spanDateFormat = 'MMMM D';

            $.fn.datepicker.dates['ru'] = {
                days: ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"],
                daysShort: ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"],
                daysMin:["<span style='color: red;'>Вс</span>","Пн","Вт","Ср","Чт","Пт","<span style='color: red;'>Сб</span>"],
                months:["Январь","Февраль","Март","Апрель","Май","Июнь","Июль","Август","Сентябрь","Октябрь","Ноябрь","Декабрь"],
                monthsShort: ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"],
                today: "Today",
                clear: "Clear",
                format: "mm/dd/yyyy",
                titleFormat: "MM yyyy", /* Leverages same syntax as 'format' */
                weekStart: 1
            };
            var yearFromNow = new Date(new Date().setFullYear(new Date().getFullYear() + 1));
            dateSelect.datepicker({
                autoclose: true,
                format: "yyyy-mm-dd",
                maxViewMode: 0,
                startDate: "now",
                endDate: yearFromNow,
                disableTouchKeyboard: true,
                language: _this.settings.localization.datepicker_language
            }).on('change', function() {
                if(dateDepart.val()){
                    var start = dateDepart.datepicker('getDate').getDate() + ' ' + _this.settings.localization.month_names[dateDepart.datepicker('getDate').getMonth()] + ', ' + _this.settings.localization.weekdays_short[dateDepart.datepicker('getDate').getDay()];
                    spanDepart.text(start.toLowerCase());
                }
                if(dateReturn.val()){
                    var end = dateReturn.datepicker('getDate').getDate() + ' ' + _this.settings.localization.month_names[dateReturn.datepicker('getDate').getMonth()] + ', ' + _this.settings.localization.weekdays_short[dateReturn.datepicker('getDate').getDay()];
                    spanReturn.text(end.toLowerCase());
                    iconReturnCal.hide();
                    iconReturnDel.show();
                    dateReturn.css('font-size', '0');
                    oneway_input.val(0);
                }
                $(document).find('.datepicker tbody').removeClass('with-return-button');
            }).on('click', function() {
                if(container.find('.twidget-passengers-detail').hasClass('active')){
                    container.find('.twidget-passengers-detail').trigger('click');
                }
            });
            dateSelect.trigger('change');

            dateDepart.change(function(){
                dateReturn.focus();
            });

            iconReturnDel.click(function() {
                $(document).find('.datepicker').hide();
                $(this).hide();
                iconReturnCal.show();
                dateReturn.val('').css('font-size', '14px');
                spanReturn.text('');
                oneway_input.val(1);
                oneway_input.removeAttr('disabled');
            });
            dateReturn.focus(function(){
                setTimeout(function(){
                    if(!$(document).find('.datepicker tbody').hasClass('with-return-button')){
                            $(document).find('.datepicker tbody .datepicker-cancel-return-date').parent().remove();
                            $(document).find('.datepicker tbody').append('<tr><td class="datepicker-cancel-return-date">'+_this.settings.localization.datepicker_return_ticket_caption+'</td></tr>');
                            $(document).find('.datepicker tbody').addClass('with-return-button');
                            $(document).find('.datepicker-cancel-return-date').click(function(){
                                iconReturnDel.click()
                            });
                            dateReturn.datepicker('show');
                        }
                    }, 1);
            });
            dateReturn.datepicker()
                .on('changeMonth', function() {
                    setTimeout(function(){
                        $(document).find('.datepicker tbody').removeClass('with-return-button');
                        $(document).find('.datepicker tbody .datepicker-cancel-return-date').parent().remove();
                        $(document).find('.datepicker tbody').append('<tr><td class="datepicker-cancel-return-date">'+_this.settings.localization.datepicker_return_ticket_caption+'</td></tr>');
                        $(document).find('.datepicker tbody').addClass('with-return-button');
                        $(document).find('.datepicker-cancel-return-date').click(function(){
                            iconReturnDel.click()
                        });
                    }, 1);
                });

            $('.twidget-icon-cal, .twidget-date-text').click(function(){
                $(this).parent().find('input').trigger('focus');
            });

            if(_this.settings.default_origin) {
                $.getJSON("https://autocomplete.travelpayouts.com/jravia?locale="+_this.settings.locale+"&with_countries=false&q="+_this.settings.default_origin, function (data) {
                    if(data){
                        container.find("#twidget-origin").off('focusout').on('focusout', function(){
                            container.find('#twidget-origin').val(data[0].city_name);
                            container.find('.twidget-origin-iata').text(data[0].code);
                            container.find(".twidget-origin .twidget-pseudo-name").text(data[0].city_name);
                            container.find(".twidget-origin .twidget-pseudo-country-name").text(', '+data[0].country_name);
                            origin_iata_input.val(data[0].code);
                        });
                        container.find('#twidget-origin').trigger('focusout');
                    }
                });
            } else {
                $.getJSON("https://www.travelpayouts.com/whereami?locale="+_this.settings.locale, function (data) {
                    if(data){
                        container.find("#twidget-origin").off('focusout').on('focusout', function(){
                            container.find('#twidget-origin').val(data.name);
                            container.find('.twidget-origin-iata').text(data.iata);
                            container.find(".twidget-origin .twidget-pseudo-name").text(data.name);
                            container.find(".twidget-origin .twidget-pseudo-country-name").text(', '+data.country_name);
                            origin_iata_input.val(data.iata);
                        });
                        container.find('#twidget-origin').trigger('focusout');
                    }
                });
            }


            container.find("#twidget-origin").keydown(function() {
                container.find(".twidget-origin .twidget-pseudo-name").html('');
                container.find(".twidget-origin .twidget-pseudo-country-name").html('');
                origin_iata_input.val('');
                container.find('.twidget-origin-iata').text('');
            });
            container.find("#twidget-origin").keyup(function(){
                var v = $(this).val(),
                    this_input = $(this),
                    citiesSortedArr = [],
                    citiesOrigSort = [];
                $.getJSON("https://autocomplete.travelpayouts.com/jravia?locale="+_this.settings.locale+"&with_countries=false&q="+v, function (data) {
                    container.find(".twidget-origin .twidget-auto-fill-wrapper ul li").remove();
                    $.each(data, function(key, value){
                        if(value.city_name) {
                            if(!citiesSortedArr[value.city_code]){
                                citiesSortedArr[value.city_code] = [];
                            }
                            if(!value.name){
                                citiesSortedArr[value.city_code].main = value;
                            } else {
                                citiesSortedArr[value.city_code].push(value);
                            }
                            citiesOrigSort.push(value.city_code);
                        }
                    });
                    citiesOrigSort = $.grep(citiesOrigSort, function(v, k){
                        return $.inArray(v ,citiesOrigSort) === k;
                    });
                    $.each(citiesOrigSort, function(key, value){
                        if(citiesSortedArr[value].main) {
                            container.find(".twidget-origin .twidget-auto-fill-wrapper ul").append(
                                '<li class="clearfix">' +
                                '<span class="twidget-city-name" data-name="' + citiesSortedArr[value].main.city_name + '" data-country="' + citiesSortedArr[value].main.country_name + '">' + citiesSortedArr[value].main.city_name + ', <span>' + citiesSortedArr[value].main.country_name + '</span></span>' +
                                '<span class="twidget-num-hotel">' + citiesSortedArr[value].main.code + '</span><br>' +
                                '<span class="twidget-city-airport-name">' +  _this.settings.localization.avia_all_airports_caption + '</span></li>'
                            );
                        }
                        $.each(citiesSortedArr[value], function(childKey, childValue){
                            container.find(".twidget-origin .twidget-auto-fill-wrapper ul").append(
                               '<li class="clearfix" ' + (citiesSortedArr[value].main && childKey != 'main' ? 'style="padding-left:30px;"' : '') + '>' +
                               '<span class="twidget-city-name" data-name="' + childValue.city_name + '" data-country="' + childValue.country_name + '">' + childValue.city_name + (citiesSortedArr[value].main && childKey != 'main' ? '' : ', <span>' + childValue.country_name + '</span>') + '</span>' +
                               '<span class="twidget-num-hotel">' + childValue.code + '</span><br>' +
                               '<span class="twidget-city-airport-name">' + (childValue.name ? childValue.name : _this.settings.localization.avia_all_airports_caption ) + '</span></li>'
                            );
                        });
                    });
                    var focus_timeout = 0;
                    if(data[0]){
                        container.find("#twidget-origin").off('focusout').on('focusout', function(){
                            focus_timeout = setTimeout(function(){
                                this_input.val(data[0].city_name);
                                container.find('.twidget-origin-iata').text(data[0].code);
                                origin_iata_input.val(data[0].code);
                                this_input.parent().find('.twidget-pseudo-name').text(data[0].city_name);
                                this_input.parent().find('.twidget-pseudo-country-name').text(', '+data[0].country_name);
                                container.find(".twidget-origin .twidget-auto-fill-wrapper ul li").remove();
                                container.find(".twidget-origin .twidget-auto-fill-wrapper").removeClass('active');
                            }, 200);
                        });
                    }
                    container.find(".twidget-origin .twidget-auto-fill-wrapper").removeClass('active');
                    container.find(".twidget-origin .twidget-auto-fill-wrapper ul li").each(function(){
                        $(this).parent().parent().addClass('active');
                        $(this).click(function(){
                            clearTimeout(focus_timeout);
                            var city = $(this).find('.twidget-city-name').attr('data-name'),
                                country = $(this).find('.twidget-city-name').attr('data-country'),
                                iata = $(this).find('.twidget-num-hotel').text();
                            this_input.val(city);
                            container.find('.twidget-origin-iata').text(iata);
                            origin_iata_input.val(iata);
                            this_input.parent().find('.twidget-pseudo-name').text(city);
                            this_input.parent().find('.twidget-pseudo-country-name').text(', '+country);
                            container.find("#twidget-origin").off('focusout').on('focusout', function(){
                                this_input.val(city);
                                container.find('.twidget-origin-iata').text(iata);
                                origin_iata_input.val(iata);
                                this_input.parent().find('.twidget-pseudo-name').text(city);
                                this_input.parent().find('.twidget-pseudo-country-name').text(', '+country);
                            });
                            container.find(".twidget-origin .twidget-auto-fill-wrapper ul li").remove();
                            container.find(".twidget-origin .twidget-auto-fill-wrapper").removeClass('active');
                        });
                    });
                    if(!container.find("#twidget-origin").is(':focus')){
                        container.find("#twidget-origin").trigger('focusout');
                    }
                });

            });

            if(_this.settings.default_destination) {
                $.getJSON("https://autocomplete.travelpayouts.com/jravia?locale="+_this.settings.locale+"&with_countries=false&q="+_this.settings.default_destination, function (data) {
                    if(data){
                        container.find("#twidget-destination").off('focusout').on('focusout', function(){
                            container.find('#twidget-destination').val(data[0].city_name);
                            container.find('.twidget-destination-iata').text(data[0].code);
                            container.find(".twidget-destination .twidget-pseudo-name").text(data[0].city_name);
                            container.find(".twidget-destination .twidget-pseudo-country-name").text(', '+data[0].country_name);
                            destination_iata_input.val(data[0].code);
                        });
                    }
                    container.find('#twidget-destination').trigger('focusout');
                });
            }
			
           if(_this.settings.lock_destination == false){
			container.find("#twidget-destination").keydown(function() {
                container.find(".twidget-destination .twidget-pseudo-name").text('');
                container.find(".twidget-destination .twidget-pseudo-country-name").text('');
                destination_iata_input.val('');
                container.find('.twidget-destination-iata').text('');
            });
            container.find("#twidget-destination").keyup(function(){
                var v = $(this).val(),
                    this_input = $(this),
                    citiesSortedArr = [],
                    citiesOrigSort = [];
                $.getJSON("https://autocomplete.travelpayouts.com/jravia?locale="+_this.settings.locale+"&with_countries=false&q="+v, function (data) {
                    container.find(".twidget-destination .twidget-auto-fill-wrapper ul li").remove();
                    $.each(data, function(key, value){
                        if(value.city_name) {
                            if(!citiesSortedArr[value.city_code]){
                                citiesSortedArr[value.city_code] = [];
                            }
                            if(!value.name){
                                citiesSortedArr[value.city_code].main = value;
                            } else {
                                citiesSortedArr[value.city_code].push(value);
                            }
                            citiesOrigSort.push(value.city_code);
                        }
                    });
                    citiesOrigSort = $.grep(citiesOrigSort, function(v, k){
                        return $.inArray(v ,citiesOrigSort) === k;
                    });
                    $.each(citiesOrigSort, function(key, value){
                        if(citiesSortedArr[value].main) {
                            container.find(".twidget-destination .twidget-auto-fill-wrapper ul").append(
                                '<li class="clearfix">' +
                                '<span class="twidget-city-name" data-name="' + citiesSortedArr[value].main.city_name + '" data-country="' + citiesSortedArr[value].main.country_name + '">' + citiesSortedArr[value].main.city_name + ', <span>' + citiesSortedArr[value].main.country_name + '</span></span>' +
                                '<span class="twidget-num-hotel">' + citiesSortedArr[value].main.code + '</span><br>' +
                                '<span class="twidget-city-airport-name">' +  _this.settings.localization.avia_all_airports_caption + '</span></li>'
                            );
                        }
                        $.each(citiesSortedArr[value], function(childKey, childValue){
                            container.find(".twidget-destination .twidget-auto-fill-wrapper ul").append(
                                '<li class="clearfix" ' + (citiesSortedArr[value].main && childKey != 'main' ? 'style="padding-left:30px;"' : '') + '>' +
                                '<span class="twidget-city-name" data-name="' + childValue.city_name + '" data-country="' + childValue.country_name + '">' + childValue.city_name + (citiesSortedArr[value].main && childKey != 'main' ? '' : ', <span>' + childValue.country_name + '</span>') + '</span>' +
                                '<span class="twidget-num-hotel">' + childValue.code + '</span><br>' +
                                '<span class="twidget-city-airport-name">' + (childValue.name ? childValue.name : _this.settings.localization.avia_all_airports_caption ) + '</span></li>'
                            );
                        });
                    });
                    var focus_timeout = 0;
                    if(data[0]){
                        container.find("#twidget-destination").off('focusout').on('focusout', function(){
                            focus_timeout = setTimeout(function(){
                                this_input.val(data[0].city_name);
                                container.find('.twidget-destination-iata').text(data[0].code);
                                destination_iata_input.val(data[0].code);
                                this_input.parent().find('.twidget-pseudo-name').text(data[0].city_name);
                                this_input.parent().find('.twidget-pseudo-country-name').text(', '+data[0].country_name);
                                container.find(".twidget-destination .twidget-auto-fill-wrapper ul li").remove();
                                container.find(".twidget-destination .twidget-auto-fill-wrapper").removeClass('active');
                            }, 200);
                        });
                    }
                    container.find(".twidget-destination .twidget-auto-fill-wrapper").removeClass('active');
                    container.find(".twidget-destination .twidget-auto-fill-wrapper ul li").each(function(){
                        $(this).parent().parent().addClass('active');
                        $(this).click(function(){
                            clearTimeout(focus_timeout);
                            var city = $(this).find('.twidget-city-name').attr('data-name'),
                                country = $(this).find('.twidget-city-name').attr('data-country'),
                                iata = $(this).find('.twidget-num-hotel').text();
                            container.find('#twidget-destination').val(city);
                            container.find('.twidget-destination-iata').text(iata);
                            destination_iata_input.val(iata);
                            this_input.parent().find('.twidget-pseudo-name').text(city);
                            this_input.parent().find('.twidget-pseudo-country-name').text(', '+country);
                            /* input focusout update start */
                            container.find("#twidget-destination").off('focusout').on('focusout', function(){
                                container.find('#twidget-destination').val(city);
                                container.find('.twidget-destination-iata').text(iata);
                                destination_iata_input.val(iata);
                                this_input.parent().find('.twidget-pseudo-name').text(city);
                                this_input.parent().find('.twidget-pseudo-country-name').text(', '+country);
                            });
                            container.find(".twidget-destination .twidget-auto-fill-wrapper ul li").remove();
                            container.find(".twidget-destination .twidget-auto-fill-wrapper").removeClass('active');
                        });
                    });
                    if(!container.find("#twidget-destination").is(':focus')){
                        container.find("#twidget-destination").trigger('focusout');
                    }
                });
            });
		   }

            container.find("#twidget-city-hotel").keyup(function(){
                var v = $(this).val(),
                    this_input = $(this);
                $.getJSON("https://engine.hotellook.com/api/v2/lookup.json?query="+v+"&lang="+_this.settings.locale+"&limit=4", function (data) {
                    container.find(".twidget-city-hotel .twidget-auto-fill-wrapper ul li").remove();
                    /* append cities */
                    $.each(data.results.locations, function(key, value){
                        container.find(".twidget-city-hotel .twidget-auto-fill-wrapper ul").append(
                            '<li class="clearfix ' + (key == 0 ? 'main-city' : '') + '">'+
                            '<span class="twidget-city-name" data-destination="'+value.cityName+'" data-country="'+value.countryName+'">'+value.cityName+', <span>'+value.countryName+'</span></span>'+
                            '<span class="twidget-num-hotel">'+value.hotelsCount+' ' + (value.hotelsCount > 5 || value.hotelsCount < 1 ? _this.settings.localization.hotels_count_caption_5 : (value.hotelsCount == 1 ? _this.settings.localization.hotels_count_caption_1 : _this.settings.localization.hotels_count_caption_2)) + '</span></li>'
                        );
                   });
                    var focus_destination = '',
                        focus_country = '',
                        focus_timeout = 0;
                    if(data.results.hotels[0]) {
                        focus_destination = data.results.hotels[0].label;
                        focus_country = data.results.hotels[0].locationName;
                    }
                    if(data.results.locations[0]) {
                        focus_destination = data.results.locations[0].cityName;
                        focus_country = data.results.locations[0].countryName;
                    }
                    if(focus_destination){
                        container.find("#twidget-city-hotel").off('focusout').on('focusout', function(){
                            focus_timeout = setTimeout(function(){
                                container.find("#twidget-city-hotel").val(focus_destination);
                                destination_hotel_input.val(focus_destination);
                                container.find(".twidget-city-hotel .twidget-pseudo-name").text(focus_destination);
                                container.find(".twidget-city-hotel .twidget-pseudo-country-name").text(', '+focus_country);
                                container.find(".twidget-city-hotel .twidget-auto-fill-wrapper ul li").remove();
                                container.find(".twidget-city-hotel .twidget-auto-fill-wrapper").removeClass('active');
                            }, 200);
                        });
                    }
                    container.find(".twidget-city-hotel .twidget-auto-fill-wrapper").removeClass('active');
                    container.find(".twidget-city-hotel .twidget-auto-fill-wrapper ul li").each(function(){
                        $(this).parent().parent().addClass('active');
                        $(this).click(function(){
                            clearTimeout(focus_timeout);
                            var destination = $(this).find('.twidget-city-name').attr('data-destination'),
                                country = $(this).find('.twidget-city-name').attr('data-country');
                            container.find("#twidget-city-hotel").val(destination);
                            destination_hotel_input.val(destination);
                            container.find(".twidget-city-hotel .twidget-pseudo-name").text(destination);
                            container.find(".twidget-city-hotel .twidget-pseudo-country-name").text(', '+country);
                            container.find("#twidget-city-hotel").off('focusout').on('focusout', function(){
                                container.find("#twidget-city-hotel").val(destination);
                                destination_hotel_input.val(destination);
                                container.find(".twidget-city-hotel .twidget-pseudo-name").text(destination);
                                container.find(".twidget-city-hotel .twidget-pseudo-country-name").text(', '+country);
                            });
                            container.find(".twidget-city-hotel .twidget-auto-fill-wrapper ul li").hide();
                            container.find(".twidget-city-hotel .twidget-auto-fill-wrapper").removeClass('active');
                        });
                    });
                    if(!container.find("#twidget-city-hotel").is(':focus')){
                        container.find("#twidget-city-hotel").trigger('focusout');
                    }
                });
            });


            container.find('.twidget-pseudo-input').click(function(){
                $(this).parent().find('input[type="text"]').select();
            });
            $('#twidget-origin, #twidget-destination, #twidget-city-hotel').click(function(){
                $(this).select();
            });

        },
        widget_html: function() {
            var _this = this;
            $(this.element).html(
            '    <div class="twidget-tabs">'+
            '        <div class="twidget-tab-content">'+
            '            <div id="twidget-tab1" class="twidget-tab active">'+
            '                <div class="twidget-header" ' + (_this.settings.open_in_new_tab ? 'target="_blank"' : '') + '>'+
            '                    <a href="' + _this.settings.localization.avia_logo_link + '?marker=' + _this.settings.marker + '" class="twidget-logo">' + _this.settings.localization.avia_logo_content + '</a>'+
            '                    <a href="' + _this.settings.localization.avia_logo_link + '?marker=' + _this.settings.marker + '" class="twidget-title">'+_this.settings.localization.avia_logo_caption+'</a>'+
            '                </div>'+
            '                <div class="clearfix"></div>'+
            '                <form action="' + _this.settings.localization.avia_submit_domain + '" method="get" autocomplete="off" ' + (_this.settings.open_in_new_tab ? 'target="_blank"' : '') + '>'+
            '                    <ul class="twidget-form-list clearfix">'+
            '                        <li class="twidget-origin">'+
            '                            <div class="twidget-input-box">'+
            '                                <label for="twidget-origin">'+_this.settings.localization.avia_input_origin_label+'</label>'+
            '                                <input type="text" id="twidget-origin" placeholder="'+_this.settings.localization.avia_input_origin_label+'" required>'+
            '                                <input type="hidden" name="origin_iata">'+
            '                                <div class="twidget-pseudo-input">'+
            '                                   <span class="twidget-pseudo-name"></span><span class="twidget-pseudo-country-name"></span>'+
            '                                </div>'+
            '                            </div>'+
            '                            <div class="twidget-origin-iata"></div>'+
            '                            <div class="twidget-auto-fill-wrapper" data-type="avia">'+
            '                                <ul></ul>'+
            '                            </div>'+
            '                        </li>'+
            '                        <li class="twidget-destination ' + (_this.settings.lock_destination ? 'twidget-input-locked' : '') + '">'+
            '                            <div class="twidget-input-box">'+
            '                                <label for="twidget-origin">'+_this.settings.localization.avia_input_destination_label+'</label>'+
            '                                <input type="text" ' + (_this.settings.lock_destination ? 'disabled' : '') + ' id="twidget-destination" placeholder="'+_this.settings.localization.avia_input_destination_label+'" required>'+
            '                                <input type="hidden" name="destination_iata">'+
            '                                <div class="twidget-pseudo-input">'+
            '                                   <span class="twidget-pseudo-name"></span><span class="twidget-pseudo-country-name"></span>'+
            '                                </div>'+
            '                            </div>'+
            '                            <div class="twidget-destination-iata"></div>'+
            '                            <div class="twidget-auto-fill-wrapper" data-type="avia"><ul></ul></div>'+
            '                        </li>'+
            '                        <li id="twidget-flight-datepicker" class="twidget-flight-dates input-daterange input-group clearfix">'+
            '                            <div class="twidget-dep-date twidget-form-item">'+
            '                                <div class="twidget-input-box">'+
            '                                    <label for="twidget-origin">'+_this.settings.localization.avia_input_date_start+'</label>'+
            '                                    <input type="text" name="depart_date" placeholder="'+_this.settings.localization.avia_input_date_start+'" required value="'+dateOneWeekLater.getFullYear()+'-'+(dateOneWeekLater.getMonth()+1)+'-'+dateOneWeekLater.getDate()+'">'+
            '                                    <div class="twidget-icon-cal"></div>'+
            '                                    <span class="twidget-date-text twidget-date-depart"></span>'+
            '                                </div>'+
            '                            </div>'+
            '                            <div class="twidget-return-date twidget-form-item">'+
            '                                <div class="twidget-input-box">'+
            '                                    <label for="twidget-origin">'+_this.settings.localization.avia_input_date_end+'</label>'+
            '                                    <input type="text" name="return_date" placeholder="'+_this.settings.localization.avia_input_date_end+'" value="'+dateTwoWeekLater.getFullYear()+'-'+(dateTwoWeekLater.getMonth()+1)+'-'+dateTwoWeekLater.getDate()+'">'+
            '                                    <div class="twidget-icon-cal""></div>'+
            '                                    <div class="twidget-icon-delete" style="display: none;"></div>'+
            '                                    <span class="twidget-date-text twidget-date-return"></span>'+
            '                                </div>'+
            '                            </div>'+
            '                        </li>'+
            '                        <input type="hidden" name="oneway" disabled value="0">'+
            '                        <li class="twidget-passengers">'+
            '                            <label for="twidget-passengers-detail">'+_this.settings.localization.avia_passengers_select_caption+'</label>'+
            '                            <div class="twidget-passengers-detail">'+
            '                                <div class="twidget-pas-no"><span id="twidget-pas">1</span> <span class="twidget-pas-caption">'+_this.settings.localization.avia_passengers_caption_1+'</span></div>'+
            '                                <div class="twidget-class">'+_this.settings.localization.avia_passengers_economy_class+'</div>'+
            '                            </div>'+
            '                            <div id="twidget-passenger-form" style="display: none;">'+
            '                                <div class="twidget-passenger-form-wrapper">'+
            '                                    <ul class="twidget-age-group">'+
            '                                        <li>'+
            '                                            <div class="twidget-cell twidget-age-name">' + _this.settings.localization.avia_passengers_select_adults + '</div>'+
            '                                            <div class="twidget-cell twidget-age-select">'+
            '                                                <span class="twidget-dec twidget-q-btn" data-age="adults">-</span><span class="twidget-num"><input type="text" name="adults" value="1"></span><span class="twidget-inc twidget-q-btn" data-age="adults">+</span>'+
            '                                            </div>'+
            '                                        </li>'+
            '                                        <li>'+
            '                                            <div class="twidget-cell twidget-age-name">' + _this.settings.localization.avia_passengers_select_children + '</div>'+
            '                                            <div class="twidget-cell twidget-age-select">'+
            '                                                <span class="twidget-dec twidget-q-btn" data-age="children">-</span><span class="twidget-num"><input type="text" name="children" value="0"></span><span class="twidget-inc twidget-q-btn" data-age="children">+</span>'+
            '                                            </div>'+
            '                                        </li>'+
            '                                        <li>'+
            '                                            <div class="twidget-cell twidget-age-name">' + _this.settings.localization.avia_passengers_select_infants + '</div>'+
            '                                            <div class="twidget-cell twidget-age-select">'+
            '                                                <span class="twidget-dec twidget-q-btn" data-age="infants">-</span><span class="twidget-num"><input type="text" name="infants" value="0"></span><span class="twidget-inc twidget-q-btn" data-age="infants">+</span>'+
            '                                            </div>'+
            '                                        </li>'+
            '                                    </ul>'+
            '                                    <div class="twidget-pas-class">'+
            '                                        <div class="twidget-pass-check">'+
            '                                            <input type="checkbox" class="twidget-pass-class">'+
            '                                            <label>' + _this.settings.localization.avia_passengers_business_class_checkbox + '</label>'+
            '                                            <input type="hidden" name="trip_class" value="0">'+
            '                                        </div>'+
            '                                    </div>'+
            '                                    <ul class="twidget-age-group">'+
            '                                        <li class="twidget-passengers-ready-button-wrapper">'+
            '                                            <div class="twidget-passengers-ready-button">' + _this.settings.localization.avia_passengers_select_ready_button + '</div>'+
            '                                        </li>'+
            '                                    </ul>'+
            '                                </div>'+
            '                            </div>'+
            '                        </li>'+
            '                        <input type="hidden" name="marker" value="11111">'+
            '                        <input type="hidden" name="with_request" value="1">'+
            '                        <li class="twidget-submit-button">'+
            '                            <button type="submit">'+_this.settings.localization.avia_submit_button_text+'</button>'+
            '                        </li>'+
            '                    </ul>'+
            '                </form>'+
            '                <div class="twidget-tab-bottom">'+
            '                </div>'+
            '            </div>'+
            '    </div>'+
            '');
        }
    } );

    
    $.fn[ pluginName ] = function( options ) {
        return this.each( function() {
            if ( !$.data( this, "plugin_" + pluginName ) ) {
                $.data( this, "plugin_" +
                pluginName, new Plugin( this, options ) );
            }
        } );
    };

    $('html').click(function(){
        $('.twidget-auto-fill-wrapper.active ul li:first-child').trigger('click');
    });

})
( jQuery, window, document );